import { SignUpForm } from "./SignUpForm";

export default SignUpForm;
